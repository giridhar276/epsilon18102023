

import pymysql

#step1

try:
    db = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123')
    #print(db)
    # create cursor
    cursor = db.cursor()
    #step2
    query = "select * from epsilon.adultinfo"
    #step3
    cursor.execute(query)
    #step4
    for record in cursor.fetchall():
        print(record)
    #step5
    db.close()
except Exception as err:
    print(err)
