

import pymysql
from openpyxl import Workbook
import time
wb = Workbook()
#step1

try:
    filename = time.strftime('%d_%b_%Y.xlsx')
    db = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123')
    #print(db)
    # create cursor
    cursor = db.cursor()
    #step2
    # grab the active worksheet
    ws = wb.active
    query = "select * from epsilon.adultinfo"
    #step3
    cursor.execute(query)
    #step4
    for record in cursor.fetchall():
        ws.append(record)
    #step5
    db.close()
    wb.save(filename)
except Exception as err:
    print(err)
