import requests
import json
r = requests.get('https://api.github.com/users/giridhar276/gists', auth=('giridhar276','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'))
print(r.status_code)


info = json.loads(r.text)
print(info)
for item in info:
    server = "https://api.github.com"
    gid = item["id"]
    user='giridhar276'
    url = server + "/gists/" + gid
    r1 = requests.delete(url, auth=(user,'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'))
    print(r1)
    print(r1.text)
    

