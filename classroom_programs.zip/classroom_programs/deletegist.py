    
import requests
import json


server = "https://api.github.com"
url = server + "/gists"
user = "giridhar276"
#passwd = getpass.getpass('Password:')
print("checking ", url, "using user:", user)

gid = ''
url = server + "/gists/" + gid

r1 = requests.delete(url, auth=(user,''))
print(r1)
print(r1.text)
