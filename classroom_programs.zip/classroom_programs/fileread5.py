'''
write a program to read adult.csv and display the below output

Total male count  : xxx
Toral female count: xx
'''





import csv
malecount = 0
femalecount = 0
with open('adult.csv') as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        gender = line[9].strip()
        if gender == 'Male':
            malecount +=1
        elif gender == 'Female':
            femalecount +=1
    # displayoutput
    print("Total male count :",malecount)
    print("Total female count :",femalecount)