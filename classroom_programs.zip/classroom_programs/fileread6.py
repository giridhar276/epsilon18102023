




import csv
worklist = list()
with open('adult.csv') as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        workclass = line[1]
        worklist.append(workclass)
    # displaying the output
    for work in set(worklist):
        print(work.strip().ljust(15),worklist.count(work),"times" )