

#write a program to read adult.csv and replace United-States with US and write all the lines to backup.csv


try:
    with open('adult1111.csv','r') as fobj:
        with open('backup.csv','w') as fw:
            for line in fobj:
                line = line.replace('United-States','US')
                fw.write(line )
except TypeError as err:
    print("invalid operation")
except ValueError as err:
    print("Invalid input")
except (KeyError,ValueError ) as err:
    print("Invalid Index or key")
except FileNotFoundError as err:
    print("File is not found")
except Exception as err:
    print(err)
print("this is my regular code")





with open('adult1111.csv','r') as fobj:
    print(fobj.readlines())
print("this is my regular code")