


# tradional way # legacy way
fw = open("data.txt","w")
fw.write('hello python')
fw.close()

##########################################################
# pythonic way # always preferred
# context manager
# If any line starts with keyword with .. it is called context manager
# Advantage : file will be closed automatically when it is out of indentation
with open("data.txt","w") as fw:
    fw.write('unix shell scripting\n')
    fw.write('java\n')
    
    
with open("information.txt","w") as fw:
    for line in range(1,110):
        fw.write(str(line) + "\n")


        
        
        
        
        
    
    
    