

with open("languages.txt","r") as fobj:
    for line in fobj:
        if 'python' in line or 'pytttthon' in line or 'pytttttthon' in line:
            print(line.strip())
            
            
#  ^ : at match at the beginning of the string          
import re    
with open("languages.txt","r") as fobj:
    for line in fobj:
        if re.search('^python',line):  #re.match('python',line):   # re.match()
            print(line.strip())
            
            
#  $ : at match at the end of the string          
import re    
with open("languages.txt","r") as fobj:
    for line in fobj:
        if re.search('python$',line):
            print(line.strip())            
            
#  * : zero or more occurences of preceding character            
import re    
with open("languages.txt","r") as fobj:
    for line in fobj:
        if re.search('pyt*hon',line):
            print(line.strip())            
                        
            
          
#  + : one  or more occurences of preceding character            
import re    
with open("languages.txt","r") as fobj:
    for line in fobj:
        if re.search('pyt+hon',line):
            print(line.strip())  
            
            
#  {min,max} : min to max occurences of preceding character            
import re    
with open("languages.txt","r") as fobj:
    for line in fobj:
        if re.search('pyt{2,5}hon',line):
            print(line.strip())            
            
            
# . - any single character or digit
import re    
with open("languages.txt","r") as fobj:
    for line in fobj:
        if re.search('.ython',line):
            print(line.strip())   
            
            
# [abcmq]ython  -  aython  bython cython mython qython
# [characters] - any single character
import re    
with open("languages.txt","r") as fobj:
    for line in fobj:
        if re.search('[mjrq]ython',line):
            print(line.strip())   
            
            
            
# (word1|word2) - grouping
import re    
with open("languages.txt","r") as fobj:
    for line in fobj:
        if re.search('(python|java)',line):
            print(line.strip())



            






            
            
            
            




            
            
            
            
            
            
            
            
            
            
            
            