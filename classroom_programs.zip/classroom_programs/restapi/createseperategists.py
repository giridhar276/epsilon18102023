import os ,requests,json    
from requests.auth import HTTPBasicAuth
server = "https://api.github.com"
url = server + "/gists"
user = "giridharpython"
print("checking ", url, "using user:", user)
local_file = "githubtest0.py"
with open(local_file) as fh:
    mydata = fh.read()
files = {
    "description": "2nd test",
    "public": "true",
    "user" : user,
    "files" : {}
}
path = "C:\\Users\\w24\\Desktop\\programs"
os.chdir(path)
for file in os.listdir(path):
    if os.path.isfile(file) and file.endswith(".py"):
        with open(file) as fobj:
            content = fobj.read()
            files = {
            "description": file + " testing",
            "public": "true",
            "user" : user,
            "files": {
            file: {
            "content": content
                }
              }
            }
            files["files"].update({file :{ "content":content}})
        r1 = requests.post(url, data=json.dumps(files), auth=HTTPBasicAuth(user,'bd0d9a14ab597b2a06ddd23630821fa0dc7b800a'))
        print(r1.json())
