

print('python programming')


print(10,20,30,40,50)

val = 10
print("value is",val)

name = 'python programming'
print("I love",name)


# this is single line comment

'''
this is
multline
comment
'''