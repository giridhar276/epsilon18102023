#  + : concatenation operator
print( 4 + 5)

# objects should be same type
# we can add two numbers or two strings or two lists or tuples
print("hello" + str(9))
print("hello" + ' ' + "python")
#print([10,20] + (30,40))
print([10,20] + list((30,40)))

# repetition operator
print( 2 * 2)
print("python" * 2)

alist = [10,20]
print(alist * 2)


# check for existence 
alist = [10,20,30]
if 20 in alist:
    print("do something")
    
name = 'python'
if 'tho' in name:
    print("exists")
    
    
book = {'chap1':10 , "chap2":20}
if 'chap1' in book:
    print("key exists")
    
    
book = {'chap1':10 , "chap2":20}
if 10 in book.values():
    print("value exists")