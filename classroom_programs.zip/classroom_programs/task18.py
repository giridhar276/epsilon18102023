# -*- coding: utf-8 -*-
"""

write a program to create 10 directories as below in the current directory
- before creating check whether the directory with that name or not
  if the directory is not existing then only create the directory

dir1
dir2
..
..
dir10
"""



import os

try:
    for val  in range(1,11):
        dirname = "dir" + str(val)
        if not os.path.isdir(dirname):
            os.mkdir(dirname)
            print(dirname,"created")
        else:
            print(dirname,"already exists")
except Exception as err:
    print(err)
    
    


    
    