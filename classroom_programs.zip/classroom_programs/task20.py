
"""
write a program to display the below information

1) current working directory   
2) login name
3) current process id
4) current python version
5) all the libraries available in python
6) all the environment variables
7) operating system name
8) platform name
9)current date and time
10)statistics of adult.csv file   ( display accessed tile , modified time, filesize )
11)create empty file with today's timestamp	  ( Eg: 21_Sep_2023.csv )

"""
import platform
import os
import sys
import datetime
import time
#current working directory  
print(os.getcwd())
#login name
print(os.getlogin())
# current process id
print(os.getpid())
#current python version
print(platform.python_version())
print(sys.version)
# all the libaries
print(sys.modules)
#all the environment variables
print(os.environ)
#operating system name
print(os.name)
print(platform.platform())
# curretn date
print(datetime.date.today())
print(datetime.datetime.now())

# get stas
print(os.stat('adult.csv'))

filename = time.strftime("%d_%b_%Y.log")
fobj = open(filename,"w")
fobj.close()
