'''
write a program to read https://www.google.com/ and display all the
available links in that wegpage

output :
https://mail.google.com/mail/&ogbl
https://www.google.com/imghp?hl=en&ogbl
https://www.google.com/?authuser=0
..
..
..
'''

import requests   # to download the wepage
from bs4 import BeautifulSoup ## beautifulsoup # to read html page

try:

    #step1 - to get the html content
    response = requests.get('https://www.google.com/')
    
    if response.status_code == 200 :
        soup = BeautifulSoup(response.text, 'html.parser')
        for link in soup.find_all('a'):
            if link.get('href').startswith("https://"):
                print(link.get('href'))
except Exception as err:
    print(err)


