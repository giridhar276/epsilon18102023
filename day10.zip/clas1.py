



# class
class Employee:
    def displayEmployee(self):
        print("Employee name is ","ram")
        
       
  
# object creation
emp1 = Employee()           #alist = [10,20]
emp1.displayEmployee()      #alist.append(30)

 