


def displayEmployee():
    print("Employee name is ","ram")
displayEmployee()