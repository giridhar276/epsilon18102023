





import boto3

region = 'ap-south-1'
session=boto3.session.Session(profile_name="user2")
# Create a Boto3 client for EC2
ec2 = session.client('ec2', region_name=region)

# List all snapshots
response = ec2.describe_snapshots()


print(response)
# Print the snapshot information
for snapshot in response['Snapshots']:
    print(f"Snapshot ID: {snapshot['SnapshotId']}")
    print(f"Volume ID: {snapshot['VolumeId']}")
    print(f"Description: {snapshot['Description']}")
    print(f"Status: {snapshot['State']}")
    print(f"Start Time: {snapshot['StartTime']}")
    print(f"Progress: {snapshot['Progress']}")
    print("------------------------------")
    print("-------------------------------")