

import boto3
session = boto3.session.Session(profile_name = 'user2')
response = session.resource(service_name = 'iam')
print(response)

for val in range(30,40):
    output = response.create_user(UserName= 'giri' + str(val))
    print("user" + str(val) ,"created")