



import boto3

iam_user='input("Enter you IAM User name to get datials like ID,ARN,CREATION DATE: ")'
session=boto3.session.Session(profile_name="user2")
iam_re=session.resource(service_name="iam",region_name="us-south-1")

try:
#   print "IAM User: EC2_S3_IAM Detatils\nUser Name: {}\nUser Id: {}\nUser ARN: {}\nUser Creation Date: {}".format(req_iam_user.user_name,req_iam_user.user_id,req_iam_user.arn,req_iam_user.create_date)
  for eacg in iam_re.groups.all():
      print(eacg)
except Exception as e:
  print(e.response['Error']['Code'])
