


class Employee:
    def getEmployee(self,name):
        #acts like a local variable
        self.name = name
            
    def displayEmployee(self):
        print("Employee name is ",self.name)
        
       
  
# object creation
emp1 = Employee()    
emp1.getEmployee('ram')    
emp1.displayEmployee()     


emp2 = Employee()        
emp2.getEmployee('Robert')    
emp2.displayEmployee()  


emp3 = Employee()        
emp3.getEmployee('Frank')    
emp3.displayEmployee() 