

# constructor is invoked automatically when the object is created
class Employee:
    #this is the constructor # predefined  # intialize the values
    def __init__(self,name,age):
        #acts like a local variable
        self.name = name
        self.age = age
            
    def displayEmployee(self):
        print("Employee name is ",self.name)
        print("Employee age  is ",self.age)
    
# object creation
emp1 = Employee('ram',29)       
emp1.displayEmployee()     


emp2 = Employee('Robert',30)        
emp2.displayEmployee()  


emp3 = Employee('Frank',35)        
emp3.displayEmployee()




 

