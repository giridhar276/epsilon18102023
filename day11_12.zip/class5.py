
## procedural style
import csv

try:
    with open('adult.csv','r') as fobj:
        reader = csv.reader(fobj)
        for line in reader:
            print(line)
except Exception as err:
    print(err)            