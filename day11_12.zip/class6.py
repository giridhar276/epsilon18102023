## procedural style
import csv

try:
    with open('adult.csv','r') as fobj:
        reader = csv.reader(fobj)
        for line in reader:
            print(line)
except Exception as err:
    print(err)            



## object oriented programming
import csv

class FileInput:
    def __init__(self,filename):
        self.filename = filename
    def displayOutput(self):
        try:
            with open(self.filename,'r') as self.fobj:
                self.reader = csv.reader(self.fobj)
                for line in self.reader:
                    print(line)
        except Exception as err:
            print(err)
        
filename = "adult.csv"
file1 = FileInput(filename)
file1.displayOutput()