

import pymysql

class Database:
    def __init__(self,host,port,user,password):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
    def connectDB(self):
        self.conn = pymysql.connect(self.host,)
        








db1 = Database('127.0.0.1',3306,'admin','giri@123')
db1.connectDB()