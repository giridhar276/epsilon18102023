


atup = (10,20,30,40)

print(atup.count(10))


# list of lists
empdb = [['ram','1-1-2000','m'],['rita''2-2-1999','F']]


# list of tuples
empdb = [('ram','1-1-2000','m'),('rita''2-2-1999','F')]



alist = [10,20,30,40]
alist[0] = 100
print(alist)


atup = (10,20,30,40)
#atup[0] = 100
print(atup)

# typecasting - converting from one object to another object
atup = (10,20,30,40)   # tuple
alist = list(atup)     # converting tuple to list
alist[0] = 100         # make changes
atup = tuple(alist)    # recovert back to tuple
print(atup)




