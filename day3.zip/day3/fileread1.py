
# method1  ( preferred)  - line by line operation
# fobj acts like file cursor or file pointer
with open('adult.csv') as fobj:
    for line in fobj:
        print(line.strip())
        print("------------")
        
# method2  - output in list format
with open('adult.csv') as fobj:
    print(fobj.readlines())
    
    
#method3 - string format    
# suggestable for reading config files only
with open('adult.csv') as fobj:
    print(fobj.read())
    
#method4     # preferred
import csv
with open('adult.csv') as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)