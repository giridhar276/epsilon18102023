'''
write a program to read adult.csv and display the below output

Total male count  : xxx
Toral female count: xx
'''





import csv
workset = set()
with open('adult.csv') as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        gender = line[9]
        print(gender)
