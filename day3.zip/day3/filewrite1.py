# file

fw = open("customers.txt","w")

fw.write('python programming\n')
fw.write('unix shel\n')
fw.write('spark\n')
fw.close()



#example2
fw = open("numbers.txt","w")
for val in range(1,10):
    fw.write(str(val) + "\n")

fw.close()



fw = open("numbers.txt","w")
for val in range(1,10):
    fw.write(str(val) + "\n")

fw.close()

# path :C:\Users\Administrator\Desktop\programs\new
#fw = open(r"C:\Users\Administrator\Desktop\programs\new\numbers.txt","w")  # raw string
#fw = open("C:/Users/Administrator/Desktop/programs/new/numbers.txt","w")
fw = open("C:\\Users\\Administrator\\Desktop\\programs\\new\\numbers.txt","w")
for val in range(1,10):
    fw.write(str(val) + "\n")

fw.close()





