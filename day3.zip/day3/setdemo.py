



aset = {10,20,20,20,30,30}
bset = {30,30,30,30,40,40,40,50}

aset.add(30)  # add element to thetuple

print(aset)
print(bset)

# all the unique elmenets of both the sets
print(aset.union(bset))  #

# all the common elements in both sets
print(aset.intersection(bset))




alist = [10,20,30]
alist.extend([10,20,30])