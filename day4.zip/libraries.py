


import datetime

print(datetime.datetime.now())

print(datetime.date.today())




import math
print(math.log(1))



import os
print(os.listdir())