




import requests
import json
try:
    url = "https://api.github.com"
    endpoint = '/user'
    finalurl = url + endpoint
    username = "giridhar276"
    token = "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"
    response = requests.get(finalurl,auth=(username,token))
    #print(type(response.text))
     
    # converting json to dict  , json.loads
    data = json.loads(response.text)
    for key,value in data.items():
        print(key.ljust(20),value)
except Exception as err:
    print(err)
    
    
    