

# shadowing the password
import getpass

username = input('Enter username ;')
password = getpass.getpass()

print("Username :",username)
print("password :",password)







