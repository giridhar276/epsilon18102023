
# builtin library
# shadowing the password
import getpass

username = input('Enter username ;')
password = getpass.getpass()

print("Username :",username)
print("password :",password)




#third party library
import pwinput

username = input('Enter username ;')
password = pwinput.pwinput(mask="*")


print("Username :",username)
print("password :",password)
