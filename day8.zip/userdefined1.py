# user defined function or block
def display(a,b):
    c = a + b
    return c
total = display(10,20)
print(total)

'''
different ways of passing arguments
-----------------------------------------
-fixed arguments
-default arguments
-keyword arguments
-variable length arguments
'''
# fixed arguments
def display(a,b):
    print(a,b)
display(10,20)

# default arguments
def display(a = 0,b = 0,c = 0):
    print(a,b,c)
display()
display(10)
display(10,20)
display(10,20,30)

#keyword arguments
def display(c,a,b):
    print(a,b,c)
display(b = 20,a = 10, c=30)




# If any object starts with * - we call it tuple
def display(*args):
    #print(args)
    for val in args:
        print(val)
display(10,20,30,40,50,45,34,45,4,43,67,43,67,43,64,45,3,3,5,"uni")



def displaydata(**kwargs):
    for key,value in kwargs.items():
        print(key,value)

displaydata(chap1 = 10 , chap2 = 20)















