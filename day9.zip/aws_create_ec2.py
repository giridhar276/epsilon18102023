
import boto3

# Replace these values with your own
region = 'ap-south-1'  # Replace with your region
image_id = 'ami-0287a05f0ef0e9d9a'  # Replace with your AMI ID
instance_type = 't2.micro'  # Replace with your instance type

session=boto3.session.Session(profile_name="user2")
# Create a Boto3 client for EC2
ec2 = session.client('ec2', region_name=region)

# Create the instance
response = ec2.run_instances(
    ImageId=image_id,
    InstanceType=instance_type,
    MinCount=1,
    MaxCount=1
)

# Print the instance id
print(f"Instance ID: {response['Instances'][0]['InstanceId']}")
