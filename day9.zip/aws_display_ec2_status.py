




import boto3

region = 'ap-south-1'
session=boto3.session.Session(profile_name="user2")
# Create a Boto3 client for EC2
ec2 = session.client('ec2', region_name=region)


# Retrieve all instances
response = ec2.describe_instances()
print(response)
# Display instance status
print("List of EC2 Instances and their status:")
for reservation in response['Reservations']:
    for instance in reservation['Instances']:
        print(f"Instance ID: {instance['InstanceId']}, Instance State: {instance['State']['Name']}")