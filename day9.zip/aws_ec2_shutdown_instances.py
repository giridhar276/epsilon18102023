
import boto3

region = 'ap-south-1'
session=boto3.session.Session(profile_name="user2")
# Create a Boto3 client for EC2
ec2 = session.client('ec2', region_name=region)


# Retrieve all instances
response = ec2.describe_instances()

# Stop all running instances
for reservation in response['Reservations']:
    for instance in reservation['Instances']:
        if instance['State']['Name'] == 'running':
            instance_id = instance['InstanceId']
            ec2.stop_instances(InstanceIds=[instance_id])
            print(f"Stopping Instance with ID {instance_id}")