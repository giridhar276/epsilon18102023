






## display buckets
import boto3

AWS_REGION = "ap-south-1"

session=boto3.session.Session(profile_name="user2")

client = session.client("s3", region_name=AWS_REGION)

response = client.list_buckets()

print("Listing Amazon S3 Buckets:")

for bucket in response['Buckets']:
    print(f"-- {bucket['Name']}")
    
    

    