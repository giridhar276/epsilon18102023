

import boto3

region = 'us-west-2'

#step1
session = boto3.session.Session(region_name=region,profile_name='user2')


#step2
# Create a Boto3 client for S3
s3 = session.client('s3', region_name=region)


# List all S3 buckets
response = s3.list_buckets()

# Display bucket names
print("List of S3 buckets:")
for bucket in response['Buckets']:
    print(f"- {bucket['Name']}")
    
    
    

import boto3

region = 'us-west-2'

#step1
session = boto3.session.Session(region_name=region,profile_name='user2')

# Create a Boto3 client for S3
s3 = session.client('s3', region_name=region)

# List all S3 buckets
response = s3.list_buckets()

# Display bucket names
print("List of S3 buckets:")
for bucket in response['Buckets']:
    print(f"- {bucket['Name']}")
    






    