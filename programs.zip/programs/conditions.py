# simple if
name = 'python programming'
if name.islower():
    print('string is lower')

# if-else
name = 'python programming'
if name.islower():
    print('string is lower')
else:
    print("string is upper")
    
# if-elif-elif-elif-elif-else
lang = input('Enter any language :')
if lang.isupper():
    print("string is upper")
elif lang.islower():
    print("string is lower")
elif lang.isnumeric():
    print("string is numeric")
else:
    print('string is alphanumeric')
    
    
    
    
    
# check for existence
name = 'python programming'
if 'ram' in name:
    print('substring exists')
    
if name.find('ram') != -1 :
    print("substring eexists")
    
    
if name.isupper():
    print("string is upper")
else:
    print("string is lower")
    
    
    
alist = [10,20,30,40,50]
if 10 in alist:
    print("value exists")
else:
    print("value not found")

    
    
    
    
    
    
    
    










