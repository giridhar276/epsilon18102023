book   = {"chap1":10 ,"chap2":20 ,"chap3":30}
print(book)

# add new key-value pairs
book['chap4'] = 40
book['chap5'] = 50
print(book)


# display value with key
print(book['chap1'])
print(book['chap2'])


# display keys
for key in book.keys():
    print(key)
    
# display values
for value in book.values():
    print(value)
    
# display one key - one value
for k,v in book.items():
    print(k,v)
    

newbook = {"chap7":70 ,"chap8":80}
finalbook = {book,newbook}
print(finalbook)