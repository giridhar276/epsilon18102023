alist = [12,45,19,52,93,2,45,32]
# list.append(value)
alist.append(49)   # add single value
print('After appending :',alist)
# list.extend(list)
alist.extend([39,81,1,73,59])  # multiple values
print('After extending :',alist)
#list.insert(index,value)
alist.insert(1,100)
print('After inserting :',alist)
#list.pop(index)  # value at that index will be removed
alist.pop(1)  # 1 is the index
              # will remove value at index1
print('after pop operation :',alist)
# list.remove(value) # index is not required
alist.remove(19)  # 19 the value
print('After removing ;',alist)
alist.reverse()
print('After reversing :',alist)
alist.sort()
print('After sortint :',alist)
print('get count :',alist.count(81))