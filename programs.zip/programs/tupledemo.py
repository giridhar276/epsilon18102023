


atup = (10,20,30,40)

print(atup.count(10))


# list of lists
empdb = [['ram','1-1-2000','m'],['rita''2-2-1999','F']]


# list of tuples
empdb = [('ram','1-1-2000','m'),('rita''2-2-1999','F')]