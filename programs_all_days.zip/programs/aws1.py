
## create bucket


import boto3

session = boto3.session.Session(profile_name ='user2',region_name='us-west-2')
print(session)

s3 = session.resource('s3')

bucket_name = "giri30102023"


s3.create_bucket(Bucket=bucket_name)

print('bucket created')




import boto3

# Replace these values with your own
region = 'us-west-2'  # Replace with your region
bucket_name = 'giri30102023'  # Replace with your bucket name

# Create a Boto3 session
session = boto3.session.Session(region_name=region,profile_name='user2')

# Create an S3 resource
s3 = session.resource('s3')

# Create a bucket
s3.create_bucket(Bucket=bucket_name)

# Print all bucket names
for bucket in s3.buckets.all():
    print(bucket.name)