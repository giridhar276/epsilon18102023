




import boto3

try:
    AWS_REGION = "ap-south-1"
    
    
    session=boto3.session.Session(profile_name="user2")
    client = session.client("s3", region_name=AWS_REGION)
    bucket_name = "giri30102023"
    location = {'LocationConstraint': AWS_REGION}
    
    response = client.create_bucket(Bucket=bucket_name, CreateBucketConfiguration=location)
    
    print("Amazon S3 bucket has been created")

except Exception as err:
    print(err)
