
import boto3
from glob import glob



AWS_REGION = "ap-south-1"
S3_BUCKET_NAME = "giri30102023"

session=boto3.session.Session(profile_name="user2")
s3_client = session.client("s3", region_name=AWS_REGION)


def upload_file(file_name, bucket, object_name=None, args=None):
    if object_name is None:
        object_name = file_name

    s3_client.upload_file(file_name, bucket, object_name, ExtraArgs=args)
    print(f"'{file_name}' has been uploaded to '{S3_BUCKET_NAME}'")
    #print("{} has been uploaded to {}".format(file_name,S3_BUCKET_NAME))


files = glob("*.py")
print(files)

for file in files:
    upload_file(file, S3_BUCKET_NAME)    
    