# class
class Employee:
    def displayEmployee(self,name):
        self.name = name
        print("Employee name is ",self.name)

  
# object creation or object instantiation
emp1 = Employee()        
emp1.displayEmployee("ram")     


emp2 = Employee()        
emp2.displayEmployee("Robert")  


emp3 = Employee()        
emp3.displayEmployee("Frank")
