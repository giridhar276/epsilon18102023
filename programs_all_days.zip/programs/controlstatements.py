


# range(start,stop,incremental)
# display all the nmumbers from 1 to 10
for i in range(1,11):
    print(i)
    
for i in range(2,11,2):
    print(i)
    
    
for i in range(1,11,2):
    print(i)
    
    
name = 'python'
for char in name:
    print(char)
    
    
alist = [10,20,30,40]
for i in alist:
    print(i,end=" ")
