

import boto3

region = 'ap-south-1'
session=boto3.session.Session(profile_name="user2")
# Create a Boto3 client for EC2
ec2 = session.client('ec2', region_name=region)


volume_id = 'vol-00740d547ed880c5a'

# Create the snapshot
response = ec2.create_snapshot(
    VolumeId=volume_id,
    Description='This is a snapshot created by user2'
)

print(response)