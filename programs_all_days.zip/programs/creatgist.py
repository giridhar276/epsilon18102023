

import requests
import json

url = "https://api.github.com"
finalurl = url + "/gists"
user = "giridhar276"
token = "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"
print("checking ", url, "using user:", user)

local_file = "db1.py"
# read the file tht you wish to upload in the string
with open(local_file) as fh:
    mydata = fh.read()
# payload 
files = {
    "description": "rest api - giri testing",
    "public": "true",
    "user" : user,
    "files": {
    local_file: {
    "content": mydata
        }
      }
}
                            # converting dict to json
r1 = requests.post(finalurl, data=json.dumps(files), auth=(user,token))
#print(r1.json())
data = json.loads(r1.text)
for key,value in data.items():
    print(key.ljust(20),value)
