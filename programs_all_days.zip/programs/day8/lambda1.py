# regular code
def display(a,b):
    c = a + b
    return c
total = display(10,20)
print(total)


# lambda function
# lambda or inline function  or anonymous function
# lambda : lambda is the replacement of single liner function

#syntax
#functionname = lambda varibales : expression

display = lambda a,b : a+b
total = display(10,20)
print(total)

display = lambda a,b : a if a > b else b
total = display(10,20)
print(total)


square = lambda x : x* x if x > 0 else 'not possible'
ans = square(10)
print(ans)

convert = lambda x : int(x)
ans = convert('10')




###############################################################

alist = ["google","unix","java"]


#output
#[ "www.google.com","www.unix.com","www.java.com"]

blist = []
alist = ["google", "yahoo", "gmail"]
display = lambda x : "www." + x + ".com"
for list in alist:
    blist.append(display(list))
print(blist)      

#map(function,iterable)
def display(x):
    return "www." + x + ".com"
alist = ["google", "yahoo", "gmail"]
print(list(map(display,alist)))

# map with lambda
alist = ["google", "yahoo", "gmail"]
print(list(map(lambda x: "www." + x + ".com",alist)))

# list comprehension
# [expression forloop]
output = [  "www." + x + ".com"    for x in alist]  
print(output)  



# filter(function,iterable)
alist = [1,2,3,4,5,6,6,7,8]
print(list(filter(lambda x: x%2 ==0,alist)))
print(list(filter(lambda x: x%2 ,alist)))

data = ["unix","java","python","ruby","shell"]
print(list(filter(lambda x:len(x)==4,data)))

























