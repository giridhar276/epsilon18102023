
import pymongo

# creating the connection
myclient = pymongo.MongoClient("mongodb://localhost:27017/")

# creating the database
mydb = myclient["housing"]

# displaying all databases
dblist = myclient.list_database_names()
print(dblist)