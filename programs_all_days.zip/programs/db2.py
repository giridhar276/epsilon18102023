



import pymysql

#step1

try:
    #step1
    db = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123',database='epsilon')
    #print(db)
    # create cursor
    cursor = db.cursor()
    #step2
    query = "insert into adultinfo values('{}','{}','{}')".format('public','BS','banker')
    #step3
    cursor.execute(query)
    #step4
    print(cursor.rowcount,"record inserted")
    db.commit()
    #step5
    db.close()
except Exception as err:
    print(err)
