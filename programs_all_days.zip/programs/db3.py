import os
import pymysql
import csv
#step1

try:
    #step1
    db = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123',database='epsilon')
    #print(db)
    # create cursor
    cursor = db.cursor()
    #step2
    rowcount = 0
    filename = 'adult.csv'
    if os.path.isfile(filename) and os.path.getsize(filename) > 0 :
        with open(filename)  as fobj:
            reader = csv.reader(fobj)
            for line in reader:
                    
                query = "insert into adultinfo values('{}','{}','{}')".format(line[1],line[6],line[3])
                #step3
                cursor.execute(query)
                
                #step4
                rowcount = rowcount  + 1
        print(rowcount,"records inserted")
    else:
        print('file not found.. please check')
    db.commit()
    #step5
    db.close()
except Exception as err:
    print(err)
