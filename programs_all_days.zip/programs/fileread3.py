import csv
with open('adult.csv') as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        workclass = line[1]
        education = line[3]
        print("Workclass :",workclass)
        print("Education :",education)
        print("---------------------")