
import csv
workset = set()
with open('adult.csv') as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        workclass = line[1]
        workset.add(workclass)
    # displaying the output
    for work in workset:
        print(work.strip())
        
        
        
import csv
worklist = []
with open('adult.csv') as fobj:
    #converting file object to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        workclass = line[1]
        if workclass not in worklist:
            worklist.append(workclass)
    # displaying the output
    for work in worklist:
        print(work.strip())