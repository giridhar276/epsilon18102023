

## method1 ; importing al the methods to your program space
import math
print(math.log(1))
print(math.tan(2))
print(math.floor(44.3))


# method2:
import math as m
print(m.log(2))
print(m.tan(2))


import matplotlib.pyplot as plt
print(plt.pie([30,30,40]))



# method3 : importing rquired methods only
from math import sin,cos,tan,log
print(sin(2))
print(cos(1))
print(tan(2))