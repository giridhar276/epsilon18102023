

import oop4


mybike = oop4.Bike(600000,100)
mybike.displayInfo()