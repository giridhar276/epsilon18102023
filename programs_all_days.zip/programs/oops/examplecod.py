

import classdemo31


output = classdemo31.Employee('gita', 1000)
print(output.displayEmployee())