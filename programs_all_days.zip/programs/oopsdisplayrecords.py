
import pymysql

class Database:
    def __init__(self,host,port,user,password):
        self.host = host
        self.port= port
        self.user = user
        self.password = password
            
    def createConnection(self):
        self.conn = pymysql.connect(host=self.host,port =self.port,user=self.user,password=self.password)
    def createCursor(self):
        self.cursor = self.conn.cursor()
    def displayRecords(self):
        query ="select * from epsilon.adultinfo"
        self.cursor.execute(query)
        for record in self.cursor.fetchall():
            print(record)
    def closeConnection(self):
        self.conn.close()
        

       
db1 = Database('127.0.0.1',3306,'root','giri@123')
db1.createConnection()
db1.createCursor()
db1.displayRecords()
db1.closeConnection()
