import pdb
pdb.set_trace()

name = 'python programming'
print(name.capitalize())
print(name.upper())
print(name.lower())
print(name.isupper())
print(name.islower())
print(name.count('p'))
print(name.replace('python', 'java'))
print(name.find('gram'))
print(name.find("afa")) # if substring is NOT found, returns -1
aname = '  python '
print(len(aname))
print(len(aname.strip()))
print(len(aname.lstrip()))
print(len(aname.rstrip()))

string = "I love {} and {}"
print(string.format('python','java'))
print(string.format('java','unix'))

bname = 'python:unix:java:oracle'
print(bname.split(":"))  #converting str to list


