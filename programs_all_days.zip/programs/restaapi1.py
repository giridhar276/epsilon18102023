


import requests
import json
try:
    url = "https://api.github.com/"
    response = requests.get(url)
    #print(type(response.text))
    data = json.loads(response.text)
    for key,value in data.items():
        print(key.ljust(20),value)
except Exception as err:
    print(err)