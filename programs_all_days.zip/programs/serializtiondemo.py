

import pandas 
import time
start = time.time()
df = pandas.read_csv('adult.csv')
end = time.time()
print(end-start)


# serializing the data to pickle file
df.to_pickle('mypandasfile.pkl')



start = time.time()
# deserialization
df_pkl = pandas.read_pickle('mypandasfile.pkl')
end = time.time()
print(end-start)
print(df_pkl)