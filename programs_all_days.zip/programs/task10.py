# -*- coding: utf-8 -*-
"""
write a program to display the below IP addresses

192.168.0.1
192.168.0.2
192.168.0.3
..
..
192.168.0.10
192.168.1.1
192.168.1.2
192.168.1.3
..
..
192.168.1.10
"""



ip = "192.168.{}.{}"

for i in range(0,2):
    for j in range(1,11):
        print(ip.format(i,j))
        
        
        
ip = "192.168."
for i in range(0,2):
    subip = ip + str(i)    #192.168.0    #192.168.1.
    for val in range(1,11):
        finalip = subip + "." +str(val)
        print(finalip)
    
    
    
    
    
    