



try:
    filename = input("Enter any filename:")
    with open(filename,'r') as fobj:
        with open('backup.csv','w') as fw:
            for line in fobj:
                line = line.replace('United-States','US')
                fw.write(line )
except Exception as err:
    print(err)
else:
    print("this is else block")
    