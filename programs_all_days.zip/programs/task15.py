# -*- coding: utf-8 -*-
"""
Created on Tue Oct 24 17:06:26 2023

@author: Administrator
"""


import os

try:
    files = os.listdir("c:\\")
    for file in files:
        print(file)
except Exception as err:
    print(err)