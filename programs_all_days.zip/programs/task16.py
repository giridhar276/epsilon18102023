# -*- coding: utf-8 -*-
"""
write a program to write the output to files.txt
 with all the files and directories line by line with proper exception handling
"""



import os

try:
    files = os.listdir()
    with open("files.txt","w") as fw:
        for file in files:
            if os.path.isfile(file):
                print(file)
                fw.write(file +"\n")
except Exception as err:
    print(err)
