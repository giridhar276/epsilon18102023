# -*- coding: utf-8 -*-
"""
write a program to remove 10 directories as below in the current directory
"""




import os

try:
    for val  in range(1,11):
        dirname = "dir" + str(val)
        if  os.path.isdir(dirname):
            os.rmdir(dirname)
            print(dirname,"removed")
        else:
            print(dirname,"not found")
except Exception as err:
    print(err)
    