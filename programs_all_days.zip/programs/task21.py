# -*- coding: utf-8 -*-
"""
create two folders as below in the local directory
source       :  ( copy few files to the source folder)
destination  :  --- will be empty --

write a program to copy all the files from source folder to destination folder
"""

import shutil
import os

try:
    source = r"C:\Users\Administrator\Desktop\programs\source"
    
    destination = r"C:\Users\Administrator\Desktop\programs\destination"
    
    
    for file in os.listdir(source):
        shutil.copy(source + "\\" + file, destination)
        print(source +file ,"copied to ",destination)
        
except Exception as err:
    print(err)