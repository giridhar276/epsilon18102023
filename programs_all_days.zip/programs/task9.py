# -*- coding: utf-8 -*-
"""
write a program to display the below IP addresses

192.168.0.1
192.168.0.2
192.168.0.3
..
..
192.168.0.10

"""

for i in range(1,11):
    print('192.168.0.' + str(i))


ip = "192.168.0.{}"
for i in range(1,11):
    print(ip.format(i))